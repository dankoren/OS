
#include "types.h"
#include "user.h"

int main(void){
    int pid;
    int first_status;
    int second_status;
    int third_status;

    pid= fork(); // the child pid is 99
    if(pid > 0){
        first_status = detach(pid);  // status = 0
        printf(1, "First status is: %d\n",first_status);
        second_status = detach(pid); // status = -1, because this process has already// detached this child, and it doesn’t have// this child anymore.
        printf(1, "Second status is: %d\n",second_status);
        third_status = detach(pid*2);
        printf(1, "Third status is: %d\n",third_status);
    }
    exit(0);

}