// Long-term locks for processes

enum mutexstate { M_UNUSED, M_USED};

struct mutex {
  uint locked;        //  indicates whether mutex is locked
  struct spinlock lk; // spinlock protecting this sleep lock
  enum mutexstate state; // state for mutex
};

