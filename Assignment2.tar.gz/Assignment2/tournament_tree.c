#include "types.h"
#include "user.h"
#include "kthread.h"
#include "tournament_tree.h"


trnmnt_tree* trnmnt_tree_alloc(int depth){
    trnmnt_tree* tr =malloc(sizeof(trnmnt_tree));
    int num_mutexes = 1;
    int i ;
    tr->depth=depth;
    for (i=0;i<depth-1;i++){
        num_mutexes *=2;
    }
    tr->num_mutexes = num_mutexes;
    tr->ids = malloc(num_mutexes* sizeof(int));
    for (i=0;i<num_mutexes;i++) {
        int id = kthread_mutex_alloc();
        if(id != -1)
            tr->ids[i] =id;
        else {
            printf(1, "couldnt allocate mutex to tree");
            trnmnt_tree_dealloc(tr);
        }
    }
        return tr;
}

int trnmnt_tree_dealloc(trnmnt_tree* tree){
    int i;
    for (i=0;i<tree->num_mutexes;i++){
        if(kthread_mutex_dealloc(tree->ids[i]) == -1){
            printf(1, "couldnt dealloc mutex from tree");
            return -1;
        }
    }
    free(tree->ids);
    free(tree);
    return 0;
}

int trnmnt_tree_acquire (trnmnt_tree* tree,int ID){
    int fake_thread_id = tree->num_mutexes+ID;
    int mutex_id;
    for(mutex_id=(fake_thread_id-1)/2;mutex_id>=0;mutex_id=(mutex_id-1)/2){
        kthread_mutex_lock(tree->ids[mutex_id]);
    }
    return 0;
}

int trnmnt_tree_release(trnmnt_tree* tree,int ID){
    int depth=tree->depth;
    int path[depth];
    int i=depth-1;
    int mutex_id;
    int fake_thread_id = tree->num_mutexes+ID;
    for(mutex_id=(fake_thread_id-1)/2;mutex_id>=0;mutex_id=(mutex_id-1)/2) {
        path[i] = mutex_id;
        i--;
    }
    for (i=0;i<depth;i++){
        kthread_mutex_unlock(tree->ids[path[i]]);
    }
    return 0;

}